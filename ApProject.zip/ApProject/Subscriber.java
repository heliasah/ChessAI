public interface Subscriber {
    void onEvent(Object obj);
}
